<?php
	
	header('Location: ../logout.php');
	exit;
	
?>